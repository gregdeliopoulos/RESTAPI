define({
  "name": "example",
  "version": "0.1.0",
  "description": "A basic apiDoc example",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-10-08T18:12:54.165Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});
